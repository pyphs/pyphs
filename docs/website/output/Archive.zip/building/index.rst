.. title: Page under construction
.. slug: building
.. date: 2016-01-29 14:41:15 UTC+01:00
.. tags: 
.. category: 
.. link: 
.. description: 
.. type: text
.. author: Antoine Falaize

This page is under construction

.. image:: /images/construction.jpg
   :height: 300px
   :scale: 100 %
   :alt: This page is under construction
   :align: center
