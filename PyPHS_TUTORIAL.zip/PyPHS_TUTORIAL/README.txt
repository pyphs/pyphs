This folder contains an introduction to the Python package PyPHS, which is available on Github at the following url:
https://github.com/pyphs/pyphs

 The folder is organized as follows:
 - A pdf file 'PyPHS_Core_primer.pdf' which recalls the Port-Hamiltonian structure that we consider in PyPHS.
 - A folder 'PyPHS_installation_procedure' that contains the procedure to install PyPHS.
 - Four folders 'PyPHS_tutoX_XXX' that corresponds to four tutorials.

 Each tutorial folder contains:
 - A python notebook,
 - A conversion of the python notebook to standard python script,
 - A conversion of the python notebook to pdf.

Tutorials content
-----------------

PyPHS_tuto1_oscillator:
- Build the PHS associated with a damped oscillator (PyPHS Core)
- Play with the PHS structure (PyPHS Core)
- Simulation and signals generation (PyPHS Simulation)

PyPHS_tuto2_lowpass
- Build the graph associated with a simple input/output passive circuit
  * the hard way: use PyPHS Graph
  * the easy way: use PyPHS Netlist
- Automated graph analysis (Graph -> Core)
- Add control parameters
- Simulation and code generation


PyPHS_tuto3_pianoem
- Add ports to Graph objects
- Connect several PyPHS Core objects to build a simple electro-mechanical piano

PyPHS_tuto4_diode_clipper
- Define custom components (Graph objects)
- Add custom components to the dictionary
- Here: build of a single component associated with two diodes with reversed bias (diode clipper)
